var searchData=
[
  ['uncvref_5ft_1559',['uncvref_t',['../namespacedetail.html#ad76afb2c3a23eb88e7efb7c5d5499574',1,'detail']]]
];
