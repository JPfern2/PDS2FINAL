var searchData=
[
  ['get_5ftemplate_5ffunction_1479',['get_template_function',['../namespacedetail.html#a34780011ee13a3ede041ddcee288f484',1,'detail']]]
];
