var searchData=
[
  ['json_5fpointer_1632',['json_pointer',['../classjson__pointer.html#ab0a623288bc1272870149ad50f799a73',1,'json_pointer']]]
];
