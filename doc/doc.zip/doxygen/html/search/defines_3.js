var searchData=
[
  ['screen_5fheight_1897',['SCREEN_HEIGHT',['../main_8cpp.html#a6974d08a74da681b3957b2fead2608b8',1,'main.cpp']]],
  ['screen_5fwidth_1898',['SCREEN_WIDTH',['../main_8cpp.html#a2cd109632a6dcccaa80b43561b1ab700',1,'main.cpp']]]
];
