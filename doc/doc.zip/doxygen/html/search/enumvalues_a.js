var searchData=
[
  ['msgpack_1597',['msgpack',['../namespacedetail.html#a0ab3b338d0eadc6890b72cccef0ea04fac40d516627022a54003ac2b74a82688a',1,'detail']]]
];
