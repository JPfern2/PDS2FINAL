var searchData=
[
  ['json_1499',['json',['../json_8hpp.html#ae6eede511f01c9f33342044d36a388fa',1,'json():&#160;json.hpp'],['../ListaDeJogadores_8cpp.html#ab701e3ac61a85b337ec5c1abaad6742d',1,'json():&#160;ListaDeJogadores.cpp']]],
  ['json_5fbase_5fclass_1500',['json_base_class',['../namespacedetail.html#ae0ea2ae325b8654ea5ce36e2c5043f0a',1,'detail']]],
  ['json_5fpointer_1501',['json_pointer',['../classbasic__json.html#afe66720a34c11920f359394a4430a16e',1,'basic_json']]],
  ['json_5fsax_5ft_1502',['json_sax_t',['../classbasic__json.html#acefb05e1022be791038db86c9963cec7',1,'basic_json']]],
  ['json_5fserializer_1503',['json_serializer',['../classbasic__json.html#ab75fd791f0b8fca724e5ed70b4956414',1,'basic_json']]]
];
