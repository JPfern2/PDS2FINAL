var searchData=
[
  ['reinterpret_5fbits_1307',['reinterpret_bits',['../namespacedetail_1_1dtoa__impl.html#a3c879bf97b806cacbcbb2da07a5ff5c8',1,'detail::dtoa_impl']]],
  ['removerjogador_1308',['removerJogador',['../classListaDeJogadores.html#a10199bbaea47e72f182d21d179c09b64',1,'ListaDeJogadores']]],
  ['replace_5fsubstring_1309',['replace_substring',['../namespacedetail.html#a6fd295e53b1dd4f46e235e6afee26d5e',1,'detail']]],
  ['reset_1310',['reset',['../classScenario.html#a5a2201cff446cd8722d47930851654ff',1,'Scenario']]],
  ['resetscored_1311',['resetScored',['../classObstacle.html#a2685e241ed74d678a5e97ab93ae5b27c',1,'Obstacle']]]
];
