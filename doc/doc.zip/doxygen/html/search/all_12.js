var searchData=
[
  ['range_5fvalue_5ft_761',['range_value_t',['../namespacedetail.html#ac2653c739e3ac41529a35735397b4f41',1,'detail']]],
  ['ranking_762',['RANKING',['../main_8cpp.html#a7899b65f1ea0f655e4bbf8d2a5714285af870eaec0f5f73245d65a8bf1a8a7fdf',1,'main.cpp']]],
  ['reallimits_763',['RealLimits',['../structdetail_1_1is__compatible__integer__type__impl_3_01RealIntegerType_00_01CompatibleNumberInt5b484fcfc2d1ae63b1211da72eabe33b.html#a57e63b51f11dce7bebf325582a6c3986',1,'detail::is_compatible_integer_type_impl&lt; RealIntegerType, CompatibleNumberIntegerType, enable_if_t&lt; std::is_integral&lt; RealIntegerType &gt;::value &amp;&amp;std::is_integral&lt; CompatibleNumberIntegerType &gt;::value &amp;&amp;!std::is_same&lt; bool, CompatibleNumberIntegerType &gt;::value &gt; &gt;']]],
  ['reference_764',['reference',['../structdetail_1_1iterator__types_3_01It_00_01void__t_3_01typename_01It_1_1difference__type_00_01tce77e1bdc2e5b392df295e4bdf270278.html#a70066015b1af4f35e09dabed204389c6',1,'detail::iterator_types&lt; It, void_t&lt; typename It::difference_type, typename It::value_type, typename It::pointer, typename It::reference, typename It::iterator_category &gt; &gt;::reference()'],['../structdetail_1_1iterator__traits_3_01T_01_5_00_01enable__if__t_3_01std_1_1is__object_3_01T_01_4_1_1value_01_4_01_4.html#af1702a8be706ef08e9de3d5a7f111a4a',1,'detail::iterator_traits&lt; T *, enable_if_t&lt; std::is_object&lt; T &gt;::value &gt; &gt;::reference()'],['../classdetail_1_1iteration__proxy__value.html#a42589c936453407a85968f970556e7cd',1,'detail::iteration_proxy_value::reference()'],['../classdetail_1_1iter__impl.html#aef4718cdd15a8743df34c4861c375144',1,'detail::iter_impl::reference()'],['../classdetail_1_1json__reverse__iterator.html#a81a4d0a61246d4ece37fd14eacfadda0',1,'detail::json_reverse_iterator::reference()'],['../classbasic__json.html#a6ca7bfb35987ce7cb8d27447cda5b80a',1,'basic_json::reference()']]],
  ['reference_5ft_765',['reference_t',['../namespacedetail.html#ae10a42b2797e1b62417091ff3d330832',1,'detail']]],
  ['reinterpret_5fbits_766',['reinterpret_bits',['../namespacedetail_1_1dtoa__impl.html#a3c879bf97b806cacbcbb2da07a5ff5c8',1,'detail::dtoa_impl']]],
  ['removerjogador_767',['removerJogador',['../classListaDeJogadores.html#a10199bbaea47e72f182d21d179c09b64',1,'ListaDeJogadores']]],
  ['replace_768',['replace',['../namespacedetail.html#abe7cfa1fd8fa706ff4392bff9d1a8298a9dde360102c103867bd2f45872f1129c',1,'detail']]],
  ['replace_5fsubstring_769',['replace_substring',['../namespacedetail.html#a6fd295e53b1dd4f46e235e6afee26d5e',1,'detail']]],
  ['require_5finput_5fiter_770',['require_input_iter',['../structordered__map.html#ac4f0c38634f809b72b8d2f31ca12cf80',1,'ordered_map']]],
  ['reset_771',['reset',['../classScenario.html#a5a2201cff446cd8722d47930851654ff',1,'Scenario']]],
  ['resetscored_772',['resetScored',['../classObstacle.html#a2685e241ed74d678a5e97ab93ae5b27c',1,'Obstacle']]],
  ['reverse_5fiterator_773',['reverse_iterator',['../classbasic__json.html#aedc059cdae078322bb0d434b2127d1cf',1,'basic_json']]],
  ['rhs_774',['rhs',['../classbasic__json.html#a3a549b97cc690cd390145249335d3768',1,'basic_json']]]
];
