var searchData=
[
  ['make_5fvoid_1048',['make_void',['../structdetail_1_1make__void.html',1,'detail']]]
];
