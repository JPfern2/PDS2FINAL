var searchData=
[
  ['from_5fjson_5ffunction_1478',['from_json_function',['../namespacedetail.html#a7d0993334c14a7e8055e1ec5ff237133',1,'detail']]]
];
