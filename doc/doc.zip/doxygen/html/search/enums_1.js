var searchData=
[
  ['cbor_5ftag_5fhandler_5ft_1565',['cbor_tag_handler_t',['../namespacedetail.html#a7c070b2bf3d61e3d8b8013f6fb18d592',1,'detail']]]
];
