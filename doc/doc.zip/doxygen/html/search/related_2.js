var searchData=
[
  ['external_5fconstructor_1631',['external_constructor',['../classbasic__json.html#a6275ed57bae6866cdf5db5370a7ad47c',1,'basic_json']]]
];
