var searchData=
[
  ['cbor_1581',['cbor',['../namespacedetail.html#a0ab3b338d0eadc6890b72cccef0ea04faaf9de350d652f0c9055ddab514bd23ea',1,'detail']]]
];
