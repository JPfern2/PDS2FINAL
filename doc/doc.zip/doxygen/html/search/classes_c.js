var searchData=
[
  ['negation_1049',['negation',['../structdetail_1_1negation.html',1,'detail']]],
  ['nonesuch_1050',['nonesuch',['../structdetail_1_1nonesuch.html',1,'detail']]]
];
