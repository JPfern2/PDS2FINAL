var searchData=
[
  ['undumped_5fchars_1429',['undumped_chars',['../classdetail_1_1serializer.html#a44a05646a5ac7caec54f97ba17cb893b',1,'detail::serializer']]]
];
