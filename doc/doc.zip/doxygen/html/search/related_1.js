var searchData=
[
  ['basic_5fjson_1630',['basic_json',['../classjson__pointer.html#ada3100cdb8700566051828f1355fa745',1,'json_pointer']]]
];
