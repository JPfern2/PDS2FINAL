var searchData=
[
  ['file_5finput_5fadapter_946',['file_input_adapter',['../classdetail_1_1file__input__adapter.html',1,'detail']]],
  ['from_5fjson_5ffn_947',['from_json_fn',['../structdetail_1_1from__json__fn.html',1,'detail']]]
];
