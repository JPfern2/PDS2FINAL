var searchData=
[
  ['discarded_1582',['discarded',['../namespacedetail.html#a917c3efabea8a20dc72d9ae2c673d632a94708897ec9db8647dfe695714c98e46',1,'detail']]],
  ['draft2_1583',['draft2',['../namespacedetail.html#ae785f1c6c99c714463b625da13a75dadaad7a9bad4532dc7571e87bb05e56660d',1,'detail']]],
  ['draft3_1584',['draft3',['../namespacedetail.html#ae785f1c6c99c714463b625da13a75dada5981540be7e4abfc0ca74258526e6b07',1,'detail']]]
];
