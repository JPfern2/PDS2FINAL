var searchData=
[
  ['bjdata_5fversion_5ft_1564',['bjdata_version_t',['../namespacedetail.html#ae785f1c6c99c714463b625da13a75dad',1,'detail']]]
];
